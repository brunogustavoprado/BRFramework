<?php

$location_logout = "exemple.php";
