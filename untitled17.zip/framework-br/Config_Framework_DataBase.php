<?php

$configDB = [
    'server' => "your_server_value",
    'user' => "your_user_value",
    'senha' => "your_password_value",
    'bd' => "your_database_value",
    'config_var' => "your_config_var_value"
];

?>