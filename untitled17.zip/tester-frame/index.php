<?php
require_once '../framework-br/BR_Framework.php';


//br()->sessionstart();
//br()->conexaobd();
//br()->authuser();
//br()->vardumpsession();
//br()->ip();
?> <br><br> <?php
//br()->uid();
?> <br><br> <?php
//br()->browser();
?> <br><br> <?php
//br()->location();
?> <br><br> <?php
//br()->memory();
//br()->sessionkill();
//br()->logout();
?> <br><br> <?php
//br()->validateemail();
br()->sendemail();
?>

